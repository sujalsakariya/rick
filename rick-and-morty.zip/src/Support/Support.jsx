import React from 'react'
import './Support.css'
import Head from '../header/Head'
import Foot from '../Footer/Foot'
const Support = () => {
  return (
    <div>
      <Head/>
      <Foot/>
    </div>
  )
}

export default Support